package minesweepergameGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class MinesweeperGUI extends JFrame {

    private JPanel gamePanel;
    private JButton[][] cellButtons;
    private boolean[][] mines;
    private boolean[][] revealed;
    private boolean[][] flagged;
    private int numRows;
    private int numCols;
    private int numMines;
    private boolean gameOver = false;

    public MinesweeperGUI() {
        setTitle("Minesweeper");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);

        String numRowsInput = JOptionPane.showInputDialog("Enter the number of rows: ");
        String numColsInput = JOptionPane.showInputDialog("Enter the number of columns: ");
        String numMinesInput = JOptionPane.showInputDialog("Enter the number of mines: ");

        if (numRowsInput == null || numColsInput == null || numMinesInput == null || numRowsInput.isEmpty() || numColsInput.isEmpty() || numMinesInput.isEmpty()) {
            System.exit(0);
            return;
        }

        numRows = Integer.parseInt(numRowsInput);
        numCols = Integer.parseInt(numColsInput);
        numMines = Integer.parseInt(numMinesInput);

        gamePanel = new JPanel(new GridLayout(numRows, numCols));
        add(gamePanel, BorderLayout.CENTER);

        cellButtons = new JButton[numRows][numCols];
        mines = new boolean[numRows][numCols];
        revealed = new boolean[numRows][numCols];
        flagged = new boolean[numRows][numCols];
        gameOver = false;

        gamePanel.setLayout(new GridLayout(numRows, numCols));

        initializeGameBoard();
        setVisible(true);
    }

    private void initializeGameBoard() {

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                JButton cellButton = new JButton();
                cellButton.setPreferredSize(new Dimension(50, 50));
                gamePanel.add(cellButton);

                cellButtons[i][j] = cellButton;

                int row = i;
                int col = j;

                cellButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!gameOver) {
                            openCell(row, col);
                        }
                    }
                });

                cellButton.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent evt) {
                        if (!gameOver && SwingUtilities.isRightMouseButton(evt)) {
                            toggleFlag(row, col);
                        }
                    }
                });
            }
        }

        placeMines();
    }

    private void placeMines() {
        Random random = new Random();
        int minesPlaced = 0;

        while (minesPlaced < numMines) {
            int row = random.nextInt(numRows);
            int col = random.nextInt(numCols);

            if (!mines[row][col]) {
                mines[row][col] = true;
                minesPlaced++;
            }
        }
    }

    private void openCell(int row, int col) {
        if (row < 0 || row >= numRows || col < 0 || col >= numCols || !cellButtons[row][col].isEnabled()) {
            return;
        }

        JButton cellButton = cellButtons[row][col];
        revealed[row][col] = true;
        cellButton.setEnabled(false);

        if (mines[row][col]) {
            cellButton.setBackground(Color.RED);
            gameOver = true;
            showMinesAndResult(gameOver);
            int option = JOptionPane.showConfirmDialog(this, "Sorry! You lost the game. Would you like to play again?", "Game Over", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                resetGame();
                new MinesweeperGUI();
            } else if (option == JOptionPane.NO_OPTION) {
                System.exit(0);
            }
        } else {
            int count = countAdjacentMines(row, col);
            if (count > 0) {
                cellButton.setText(Integer.toString(count));
            } else {
                cellButton.setEnabled(false);
                openCell(row - 1, col - 1);
                openCell(row - 1, col);
                openCell(row - 1, col + 1);
                openCell(row, col - 1);
                openCell(row, col + 1);
                openCell(row + 1, col - 1);
                openCell(row + 1, col);
                openCell(row + 1, col + 1);
            }
        }
        checkForWin();
    }

    private int countAdjacentMines(int row, int col) {
        int count = 0;

        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                if (i >= 0 && i < numRows && j >= 0 && j < numCols && mines[i][j]) {
                    count++;
                }
            }
        }

        return count;
    }

    private void toggleFlag(int row, int col) {
        if (!revealed[row][col]) {
            flagged[row][col] = !flagged[row][col];
            if (flagged[row][col]) {
                cellButtons[row][col].setText("F");
                cellButtons[row][col].setBackground(Color.GREEN);
            } else {
                cellButtons[row][col].setText("");
                cellButtons[row][col].setBackground(null);;
            }
        }
    }

    private void resetGame() {
        getContentPane().removeAll();
        initializeGameBoard();
        pack();
    }

    private void checkForWin() {
        boolean allNonMineCellsRevealed = true;

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                if (!mines[i][j] && !revealed[i][j]) {
                    allNonMineCellsRevealed = false;
                    break;
                }
            }
        }

        if (allNonMineCellsRevealed) {
            gameOver = true;
            showMinesAndResult(gameOver);
            int option = JOptionPane.showConfirmDialog(this, "Congratulations! You won the game. Would you like to play again?", "Game Over", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                resetGame();
                new MinesweeperGUI();
            } else if (option == JOptionPane.NO_OPTION) {
                System.exit(0);
            }
        }
    }

    private void showMinesAndResult(boolean win) {
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                if (mines[i][j]) {
                    if (win) {
                        cellButtons[i][j].setText("M");
                        cellButtons[i][j].setBackground(Color.RED);
                    } else {
                        cellButtons[i][j].setBackground(Color.RED);
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MinesweeperGUI();
            }
        });
    }
}
