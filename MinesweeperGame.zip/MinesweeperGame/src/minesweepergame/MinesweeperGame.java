/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minesweepergame;

import java.util.Random;
import java.util.Scanner;

public class MinesweeperGame {

    private int rows;
    private int columns;
    private char[][] board;
    private char[][] mineBoard;
    private boolean[][] revealed;
    private boolean[][] flagged;
    private int numMines;
    private boolean game;
    private static Scanner scanner = new Scanner(System.in);

    public MinesweeperGame(int rows, int columns, int numMines) {
        this.rows = rows;
        this.columns = columns;
        this.board = new char[rows][columns];
        this.mineBoard = new char[rows][columns];
        this.revealed = new boolean[rows][columns];
        this.flagged = new boolean[rows][columns];
        this.game = true;
        this.numMines = numMines;
    }

    private static void playGame() {
        try {
            System.out.print("Enter Row Number(Min 5): ");
            int boardRows = scanner.nextInt();
            System.out.print("Enter Column Number(Min 5):");
            int boardCols = scanner.nextInt();
            System.out.print("Enter Mine Number(Min 5): ");
            int boardNumMines = scanner.nextInt();

            if (boardRows <= 0 || boardRows < 5 || boardCols <= 0 || boardCols < 5 || boardNumMines <= 0 || boardNumMines < 5) {
                System.out.println("Please enter valid number.(Row and Col Min 5 , Mine Min 5)");
                playGame();
                return;
            } else {
                MinesweeperGame game = new MinesweeperGame(boardRows, boardCols, boardNumMines);
                game.run();

                System.out.print("Do you want to start a new game? (Y/N): ");
                String startNewGame = scanner.next().toUpperCase();
                if (startNewGame.equals("Y")) {
                    playGame();
                } else if (startNewGame.equals("N")) {
                    System.out.println("Thanks for playing!");
                } else {
                    System.out.println("Please enter Y or N.");
                }
            }
        } catch (java.util.InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); 
            playGame();
        }
    }

    private void run() {
        placeMines();
        System.out.println("Game has started!");
        while (game) {
            int row, col;
            printBoard();
            try {
                System.out.print("Row : ");
                row = scanner.nextInt();
                System.out.print("Column : ");
                col = scanner.nextInt();

                if (row < 1 || row > rows || col < 1 || col > columns) {
                    throw new IllegalArgumentException("Invalid input. Row and column values must be between 1 and " + rows + " for rows, and between 1 and " + columns + " for columns.");
                }

                System.out.println("Do you want to put a flag?(Y/N)");
                String flag = scanner.next().toUpperCase();

                if (flag.equals("Y")) {
                    flagCell(row - 1, col - 1);
                } else {
                    revealCell(row - 1, col - 1);
                }

                if (!game) {
                    printMine(mineBoard);
                }

                if (checkWin()) {
                    System.out.println("Congratulations! You have found all the squares that are not mines. You won!");
                    break;
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private boolean checkWin() {
        int revealedCount = 0;
        int unrevealedCount = 0;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (revealed[i][j]) {
                    revealedCount++;
                } else {
                    unrevealedCount++;
                }
            }
        }

        if (unrevealedCount == numMines && revealedCount == (rows * columns - numMines)) {
            return true;
        }

        return false;
    }

    public void revealCell(int row, int col) {// If this cell is already opened, take no action.
        if (revealed[row][col]) {
            return;
        }

        if (mineBoard[row][col] == 'X') {// Player opened a mine, lose the game.
            game = false;
            revealed[row][col] = true;
            System.out.println("You lost the game!");
            return;
        }

        // Open the cell and count nearby mines.
        int adjacentMines = countAdjacentMines(row, col);
        board[row][col] = (char) (adjacentMines + '0'); // Convert to number

        revealed[row][col] = true;

        // If this cell is empty, automatically open neighboring empty cells.
        if (adjacentMines == 0) {
            // top left
            if (row > 0 && col > 0) {
                revealCell(row - 1, col - 1);
            }
            // left
            if (col > 0) {
                revealCell(row, col - 1);
            }
            // bottom left
            if (row < rows - 1 && col > 0) {
                revealCell(row + 1, col - 1);
            }
            //up
            if (row > 0) {
                revealCell(row - 1, col);
            }
            // down
            if (row < rows - 1) {
                revealCell(row + 1, col);
            }
            // top right
            if (row > 0 && col < columns - 1) {
                revealCell(row - 1, col + 1);
            }
            // right
            if (col < columns - 1) {
                revealCell(row, col + 1);
            }
            // bottom right
            if (row < rows - 1 && col < columns - 1) {
                revealCell(row + 1, col + 1);
            }
        }
    }

    public void flagCell(int row, int col) {
        if (row >= 0 && row < rows && col >= 0 && col < columns) {
            if (!revealed[row][col]) {
                flagged[row][col] = !flagged[row][col];
            } else {
                System.out.println("Cannot flag an already revealed cell.");
            }
        } else {
            System.out.println("Invalid row or column.");
        }
    }

    private int countAdjacentMines(int row, int col) {
        int count = 0;

        // top left
        if (row > 0 && col > 0 && mineBoard[row - 1][col - 1] == 'X') {
            count++;
        }
        // left
        if (col > 0 && mineBoard[row][col - 1] == 'X') {
            count++;
        }
        // bottom left
        if (row < rows - 1 && col > 0 && mineBoard[row + 1][col - 1] == 'X') {
            count++;
        }
        // up
        if (row > 0 && mineBoard[row - 1][col] == 'X') {
            count++;
        }
        // down
        if (row < rows - 1 && mineBoard[row + 1][col] == 'X') {
            count++;
        }
        // top Right
        if (row > 0 && col < columns - 1 && mineBoard[row - 1][col + 1] == 'X') {
            count++;
        }
        // Right
        if (col < columns - 1 && mineBoard[row][col + 1] == 'X') {
            count++;
        }
        // bottom Right
        if (row < rows - 1 && col < columns - 1 && mineBoard[row + 1][col + 1] == 'X') {
            count++;
        }

        return count;
    }

    private void placeMines() {
        Random rnd = new Random();
        int minesPlace = 0;
        while (minesPlace != numMines) {
            int row = rnd.nextInt(rows);
            int col = rnd.nextInt(columns);

            if (mineBoard[row][col] != 'X') {
                mineBoard[row][col] = 'X';
                minesPlace++;
            }
        }
    }

    private void printMine(char[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                if (arr[i][j] == 'X') {
                    System.out.print(arr[i][j] + " ");
                } else {
                    System.out.print("- ");
                }
            }
            System.out.println();
        }
    }

    public void printBoard() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (revealed[i][j]) {
                    System.out.print(board[i][j] + " ");
                } else {
                    if (flagged[i][j]) {
                        System.out.print("F ");
                    } else {
                        System.out.print("# ");
                    }
                }
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        System.out.println("Welcome to Minesweeper Game!");
        playGame();
    }

}
