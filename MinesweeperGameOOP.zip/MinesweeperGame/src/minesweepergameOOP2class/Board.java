/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minesweepergameOOP2class;

import java.util.Random;

/**
 *
 * @author Yağmur BAŞOĞLU
 */
public class Board { // burda tahtadaki özellikleri tanımla daha sonra gerekliyse Cell olarak ayır
    //Tahtada satır ve sütun olur 
    //Satır ve sütünlardan bir düzlem kurmamız için 2d array lazım
    //Tahatdaki mayınlar nerelerde kordinat almamız için 2d array lazım
    //Tahatadaki herhangi bi koordinat kutucuk açılmış mı bakmamız için açılanları tatn 2d array lazım
    //Tahtadaki bayraklı olup olmayan hücreleri görmek için lazım
    //Tahataya koyulacak mayın sayımız mayınlarımız tahta üzerinde

    private int rows;
    private int columns;
    char[][] board;
    char[][] mineBoard;
    boolean[][] revealed;
    boolean[][] flagged;
    private int numMines;
    boolean game;

    public Board(int rows, int columns, int numMines) {
        this.rows = rows;
        this.columns = columns;
        this.board = new char[rows][columns];
        this.mineBoard = new char[rows][columns];
        this.revealed = new boolean[rows][columns];
        this.flagged = new boolean[rows][columns];
        this.numMines = numMines;
        this.game = true;
    }

    //Tahtayı yazdırmamız lazım
    public void printBoard() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (revealed[i][j]) {
                    System.out.print(board[i][j] + " ");
                } else {
                    if (flagged[i][j]) {
                        System.out.print("F ");
                    } else {
                        System.out.print("# ");
                    }
                }
            }
            System.out.println();
        }
    }

    //Myınları koymamız ve yazdırmamı laızm
    public void placeMines() {
        Random rnd = new Random();
        int minesPlace = 0;
        while (minesPlace != numMines) {
            int row = rnd.nextInt(rows);
            int col = rnd.nextInt(columns);

            if (mineBoard[row][col] != 'X') {
                mineBoard[row][col] = 'X';
                minesPlace++;
            }
        }
    }

    public void printMine(char[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                if (arr[i][j] == 'X') {
                    System.out.print(arr[i][j] + " ");
                } else {
                    System.out.print("- ");
                }
            }
            System.out.println();
        }
    }

    //Tahtadaki açılan kutucuklara bakmak lazım ve yanlarındaki adjavent mayınları syamak lazım
    public void revealCell(int row, int col) {// If this cell is already opened, take no action.
        if (revealed[row][col]) {
            return;
        }

        if (mineBoard[row][col] == 'X') {// Player opened a mine, lose the game.
            game = false;
            revealed[row][col] = true;
            System.out.println("You lost the game!");
            return;
        }

        // Open the cell and count nearby mines.
        int adjacentMines = countAdjacentMines(row, col);
        board[row][col] = (char) (adjacentMines + '0'); // Convert to number

        revealed[row][col] = true;

        // If this cell is empty, automatically open neighboring empty cells.
        if (adjacentMines == 0) {
            // top left
            if (row > 0 && col > 0) {
                revealCell(row - 1, col - 1);
            }
            // left
            if (col > 0) {
                revealCell(row, col - 1);
            }
            // bottom left
            if (row < rows - 1 && col > 0) {
                revealCell(row + 1, col - 1);
            }
            //up
            if (row > 0) {
                revealCell(row - 1, col);
            }
            // down
            if (row < rows - 1) {
                revealCell(row + 1, col);
            }
            // top right
            if (row > 0 && col < columns - 1) {
                revealCell(row - 1, col + 1);
            }
            // right
            if (col < columns - 1) {
                revealCell(row, col + 1);
            }
            // bottom right
            if (row < rows - 1 && col < columns - 1) {
                revealCell(row + 1, col + 1);
            }
        }
    }

    public int countAdjacentMines(int row, int col) {
        int count = 0;

        // top left
        if (row > 0 && col > 0 && mineBoard[row - 1][col - 1] == 'X') {
            count++;
        }
        // left
        if (col > 0 && mineBoard[row][col - 1] == 'X') {
            count++;
        }
        // bottom left
        if (row < rows - 1 && col > 0 && mineBoard[row + 1][col - 1] == 'X') {
            count++;
        }
        // up
        if (row > 0 && mineBoard[row - 1][col] == 'X') {
            count++;
        }
        // down
        if (row < rows - 1 && mineBoard[row + 1][col] == 'X') {
            count++;
        }
        // top Right
        if (row > 0 && col < columns - 1 && mineBoard[row - 1][col + 1] == 'X') {
            count++;
        }
        // Right
        if (col < columns - 1 && mineBoard[row][col + 1] == 'X') {
            count++;
        }
        // bottom Right
        if (row < rows - 1 && col < columns - 1 && mineBoard[row + 1][col + 1] == 'X') {
            count++;
        }

        return count;
    }

    //Tahtadaki bayrak var mı yok mu göstermen lazım
    public void flagCell(int row, int col) {
        if (row >= 0 && row < rows && col >= 0 && col < columns) {
            if (!revealed[row][col]) {
                flagged[row][col] = !flagged[row][col];
            } else {
                System.out.println("Cannot flag an already revealed cell.");
            }
        } else {
            System.out.println("Invalid row or column.");
        }
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }

    public int getNumMines() {
        return numMines;
    }

    public void setNumMines(int numMines) {
        this.numMines = numMines;
    }

}
