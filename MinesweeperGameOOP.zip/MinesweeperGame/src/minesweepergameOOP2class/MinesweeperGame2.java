/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minesweepergameOOP2class;

import java.util.Scanner;

/**
 *
 * @author Yağmur BAŞOĞLU
 */
public class MinesweeperGame2 {//Burda tahtayı çalıştırırsın oyunun akışını sağlarsın kullanıcıyla
    //Önce bir tahtayo ouna bağlaman lazım
    //Elinde bir oyun olmalı
    //Kullanıcıdan girdi alman lazım

    private Board board;
    private static Scanner scanner = new Scanner(System.in);

    public MinesweeperGame2(int rows, int columns, int numMines) {
        this.board = new Board(rows, columns, numMines);
    }

    private static void playGame() {
        try {
            System.out.print("Enter Row Number(Min 5): ");
            int boardRows = scanner.nextInt();
            System.out.print("Enter Column Number(Min 5):");
            int boardCols = scanner.nextInt();
            System.out.print("Enter Mine Number(Min 5): ");
            int boardNumMines = scanner.nextInt();

            if (boardRows <= 0 || boardRows < 5 || boardCols <= 0 || boardCols < 5 || boardNumMines <= 0 || boardNumMines < 5) {
                System.out.println("Please enter valid number.(Row and Col Min 5 , Mine Min 5)");
                playGame();
                return;
            } else {
                MinesweeperGame2 game = new MinesweeperGame2(boardRows, boardCols, boardNumMines);
                game.run();

                System.out.print("Do you want to start a new game? (Y/N): ");
                String startNewGame = scanner.next().toUpperCase();
                if (startNewGame.equals("Y")) {
                    playGame();
                } else if (startNewGame.equals("N")) {
                    System.out.println("Thanks for playing!");
                } else {
                    System.out.println("Please enter Y or N.");
                }
            }
        } catch (java.util.InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine();
            playGame();
        }
    }

    private void run() {
        board.placeMines();
        System.out.println("Game has started!");
        while (board.game) {
            int row, col;
            board.printBoard();
            try {
                System.out.print("Row : ");
                row = scanner.nextInt();
                System.out.print("Column : ");
                col = scanner.nextInt();

                if (row < 1 || row > board.getRows() || col < 1 || col > board.getColumns()) {
                    throw new IllegalArgumentException("Invalid input. Row and column values must be between 1 and " + board.getRows() + " for rows, and between 1 and " + board.getColumns() + " for columns.");
                }

                System.out.println("Do you want to put a flag?(Y/N)");
                String flag = scanner.next().toUpperCase();

                if (flag.equals("Y")) {
                    board.flagCell(row - 1, col - 1);
                } else if (flag.equals("N")) {
                    board.revealCell(row - 1, col - 1);
                } else {
                    System.out.println("Please enter Y or N.");
                }

                if (!board.game) {
                    board.printMine(board.mineBoard);
                }

                if (checkWin()) {
                    System.out.println("Congratulations! You have found all the squares that are not mines. You won!");
                    break;
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private boolean checkWin() {
        int revealedCount = 0;
        int unrevealedCount = 0;

        for (int i = 0; i < board.getRows(); i++) {
            for (int j = 0; j < board.getColumns(); j++) {
                if (board.revealed[i][j]) {
                    revealedCount++;
                } else {
                    unrevealedCount++;
                }
            }
        }

        if (unrevealedCount == board.getNumMines() && revealedCount == (board.getRows() * board.getColumns() - board.getNumMines())) {
            return true;
        }

        return false;
    }

    public static void main(String[] args) {
        System.out.println("Welcome to Minesweeper Game!");
        playGame();
    }

}
